# basic_read_write.rb

def write_data_to_file(file_name)
  File.open(file_name, 'w') do |file|
    file.puts "5"
    file.puts "Fred"
    file.puts "Sam"
    file.puts "Jill"
    file.puts "Jenny"
    file.puts "Zorro"
  end
end

def read_data_from_file(file_name)
  File.open(file_name, 'r') do |file|
    number_of_lines = file.gets.to_i
    number_of_lines.times do
      line = file.gets.chomp
      puts line
    end
  end
end

def main
  file_name = 'names.txt'
  write_data_to_file(file_name)
  read_data_from_file(file_name)
end

main


