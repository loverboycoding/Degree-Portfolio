module Genre
  POP, CLASSIC, JAZZ, ROCK = *1..4
end

$genre_names = ['Null', 'Pop', 'Classic', 'Jazz', 'Rock']

class Album
  attr_accessor :title, :artist, :genre, :tracks

  def initialize(title, artist, genre, tracks)
    @title = title
    @artist = artist
    @genre = genre
    @tracks = tracks
  end
end

class Track
  attr_accessor :name, :location

  def initialize(name, location)
    @name = name
    @location = location
  end
end

def read_track(music_file)
  track_name = music_file.gets().chomp
  track_location = music_file.gets().chomp
  track = Track.new(track_name, track_location)
  return track
end

def read_tracks(music_file, track_count)
  tracks = []

  track_count.times do
    track = read_track(music_file)
    tracks << track
  end

  return tracks
end

def print_tracks(tracks)
  tracks.each do |track|
    puts "#{track.name}\n#{track.location}"
  end
end

def read_album(music_file)
  album_artist = music_file.gets().chomp
  album_title = music_file.gets().chomp
  genre_index = music_file.gets().to_i
  track_count = music_file.gets().to_i
  tracks = read_tracks(music_file, track_count)
  album = Album.new(album_title, album_artist, genre_index, tracks)
  return album
end

def print_album(album)
  puts album.artist
  puts album.title
  puts "Genre is #{album.genre}"
  puts $genre_names[album.genre]
  print_tracks(album.tracks)
end

def main
  music_file = File.new("album.txt", "r")
  album = read_album(music_file)
  music_file.close
  print_album(album)
end

main()

