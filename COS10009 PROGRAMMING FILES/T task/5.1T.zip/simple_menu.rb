

def read_albums
  puts "You selected Load Albums. Press enter to continue"
  gets
end

def display_all_albums
  puts "You selected Display All Albums. Press enter to continue"
  gets
end

def display_albums_by_genre
  puts "You selected Display Albums By Genre. Press enter to continue"
  gets
end

def display_albums_menu
  loop do
    puts "Display Albums Menu:"
    puts "1 Display All Albums"
    puts "2 Display Albums by Genre"
    puts "3 Return to Main Menu"
    puts "Please enter your choice:"
    choice = gets.chomp.to_i

    case choice
    when 1
      display_all_albums
    when 2
      display_albums_by_genre
    when 3
      return
    else
      puts "Invalid choice. Please try again."
    end
  end
end

def main_menu
  loop do
    puts "Main Menu:"
    puts "1 Load Albums"
    puts "2 Display Albums"
    puts "3 Exit"
    puts "Please enter your choice:"
    choice = gets.chomp.to_i

    case choice
    when 1
      read_albums
    when 2
      display_albums_menu
    when 3
      
      break
    else
      puts "Invalid choice. Please try again."
    end
  end
end


main_menu

