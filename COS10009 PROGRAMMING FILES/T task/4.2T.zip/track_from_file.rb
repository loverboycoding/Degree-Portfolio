class Track
  attr_accessor :name, :location 

  def initialize(name, location)
    @name = name
    @location = location
  end 
end 

def read_track(file_path)
  track_info = File.open(file_path, "r") do |file|
    name = file.gets.chomp
    location = file.gets.chomp
    Track.new(name, location)
  end

  track_info
end 

def print_track(track)
  puts "Track name: #{track.name}"
  puts "Track location: #{track.location}"
end

def main()
  track = read_track("track.txt")
  print_track(track)
end

main() if __FILE__ == $0


