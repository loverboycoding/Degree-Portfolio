# tester_demo.rb
require "minitest/autorun"
require_relative "student"

class StudentTest < Minitest::Test
  def test_student_id_is_integer
    assert_kind_of Integer, get_student_id(2)
  end

  def test_student_name_for_id_300
    assert_equal "Jill", get_student_name_for_id(300)
  end

  def test_student_name_for_id_not_found
    assert_equal "Not Found", get_student_name_for_id(800)
  end

  def test_student_name_for_array_position_0
    assert_equal "Fred", get_student_name(0)
  end
end

