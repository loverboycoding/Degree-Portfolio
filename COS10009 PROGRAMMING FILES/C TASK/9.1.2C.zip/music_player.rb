require './input_functions'
require 'io/console'

module Genre
  POP, CLASSIC, JAZZ, ROCK = *1..4
end

$genre_names = ['Null', 'Pop', 'Classic', 'Jazz', 'Rock']

class Album
  attr_accessor :artist, :title, :label, :genre, :tracks

  def initialize(artist, title, label, genre, tracks)
    @artist = artist
    @title = title
    @label = label
    @genre = genre
    @tracks = tracks
  end
end

class Track
  attr_accessor :name, :location

  def initialize(name, location)
    @name = name
    @location = location
  end
end

def read_track(music_file)
  name = music_file.gets.strip
  location = music_file.gets.strip
  Track.new(name, location)
end

def read_tracks(music_file)
  count = music_file.gets.to_i
  tracks = []
  i = 0
  while i < count
    tracks << read_track(music_file)
    i += 1
  end
  tracks
end

def print_tracks(tracks)
  i = 0
  while i < tracks.length
    puts "#{i + 1} Track name: #{tracks[i].name}, Location: #{tracks[i].location}"
    i += 1
  end
end

def print_track(track)
  puts track.name
  puts track.location
end

def main_menu()
  albums = []
  finished = false
  until finished
    puts 'Main Menu:'
    puts '1 Read in Albums'
    puts '2 Display Albums'
    puts '3 Select an Album to play'
    puts '4 Add an Album'
    puts '5 Exit the application'
    choice = read_integer_in_range("Please enter your choice:", 1, 5)
    case choice
    when 1
      albums = read_in_albums()
    when 2
      if albums.empty?
        puts "No albums available. Please read in albums first."
      else
        display_albums(albums)
      end
    when 3
      if albums.empty?
        puts "No albums available. Please read in albums first."
      else
        play_album(albums)
      end
    when 4
      add_album(albums)
    when 5
      finished = true
    else
      puts "Please select again"
    end
  end
end

def read_in_albums()
  input = read_string("Enter a file path to an Album:")
  begin
    music_file = File.new(input, "r")
    albums = read_albums(music_file)
    music_file.close()
  rescue Errno::ENOENT
    puts "File not found. Please check the file path."
    albums = []
  end
  albums
end

def display_all_albums(albums)
  i = 0
  while i < albums.length
    puts "#{i + 1}: Title: #{albums[i].title.strip}, Artist: #{albums[i].artist.strip}, Label: #{albums[i].label.strip}, Genre: #{$genre_names[albums[i].genre.to_i].strip}"
    i += 1
  end
end

def display_albums(albums)
  finished = false
  until finished
    puts 'Display Albums Menu:'
    puts '1 Display All Albums'
    puts '2 Display Albums by Genre'
    puts '3 Return to Main Menu'
    choice = read_integer_in_range("Please enter your choice:", 1, 3)
    case choice
    when 1
      display_all_albums(albums)
    when 2
      display_genre(albums)
    when 3
      finished = true
    else
      puts "Please select again"
    end
  end
end

def play_album(albums)
  if albums.empty?
    puts "No albums available. Please read in albums first."
    return
  end

  display_all_albums(albums)
  select_album = read_integer("Enter Album number:")
  if select_album.between?(1, albums.size)
    print_album(albums[select_album - 1])
    puts "\n"
    print_tracks(albums[select_album - 1].tracks)
    select_track = read_integer("Select a Track to play:")
    if select_track.between?(1, albums[select_album - 1].tracks.size)
      puts "Playing track #{albums[select_album - 1].tracks[select_track - 1].name.strip} from album #{albums[select_album - 1].title.strip}\n"
      sleep(3)
    else
      puts "Invalid track number."
    end
  else
    puts "Invalid album number."
  end
end

def read_albums(music_file)
  count = music_file.gets.to_i
  albums = []
  i = 0
  while i < count
    albums << read_album(music_file)
    i += 1
  end
  albums
end

def read_album(file)
  artist = file.gets.strip
  title = file.gets.strip
  label = file.gets.strip
  genre = file.gets.to_i
  tracks = read_tracks(file)
  Album.new(artist, title, label, genre, tracks)
end

def print_album(album)
  puts "Title: #{album.title.strip}, Artist: #{album.artist.strip}, Label: #{album.label.strip}, Genre: #{$genre_names[album.genre.to_i].strip}"
end

def display_genre(albums)
  puts "1. Pop\n2. Classic\n3. Jazz\n4. Rock"
  user_input = read_integer_in_range("Select a genre:", 1, 4)
  i = 0
  while i < albums.length
    if user_input == albums[i].genre.to_i
      print_album(albums[i])
    end
    i += 1
  end
end

def add_album(albums)
  artist = read_string("Enter artist: ")
  title = read_string("Enter title: ")
  label = read_string("Enter label: ")
  puts "1. Pop\n2. Classic\n3. Jazz\n4. Rock"
  genre = read_integer_in_range("Enter number of genre: ", 1, 4)
  count_tracks = read_integer("Enter number of tracks: ")

  tracks = []
  i = 0
  while i < count_tracks
    track_name = read_string("Enter the name of the track:")
    track_location = read_string("Enter the location of the track:")
    tracks << Track.new(track_name, track_location)
    i += 1
  end

  new_album = Album.new(artist, title, label, genre, tracks)
  albums << new_album
  puts "Album '#{title}' by #{artist} added successfully!"
end

def pause
  puts "Press any key to continue..."
  STDIN.getch
  puts "\n"
end

def main()
  main_menu()
end

main()
