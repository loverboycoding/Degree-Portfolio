require './input_functions'
require 'io/console'

module Genre
  POP, CLASSIC, JAZZ, ROCK = *1..4
end

$genre_names = ['Null', 'Pop', 'Classic', 'Jazz', 'Rock']

class Album
  attr_accessor :artist, :title, :label, :genre, :tracks

  def initialize(artist, title, label, genre, tracks)
    @artist = artist.strip
    @title = title.strip
    @label = label.strip
    @genre = genre
    @tracks = tracks
  end
end

class Track
  attr_accessor :name, :location

  def initialize(name, location)
    @name = name.strip
    @location = location.strip
  end
end

def read_track(music_file)
  name = music_file.gets.chomp
  location = music_file.gets.chomp
  Track.new(name, location)
end

def read_tracks(music_file)
  count = music_file.gets.to_i
  tracks = []
  count.times { tracks << read_track(music_file) }
  tracks
end

def print_tracks(tracks)
  tracks.each_with_index do |track, index|
    puts "#{index + 1}. Track name: #{track.name}"
  end
end

def main_menu
  finished = false
  albums = []
  until finished
    puts 'Main Menu:'
    puts '1. Read in Albums'
    puts '2. Display Albums'
    puts '3. Select an Album to play'
    puts '4. Add an Album'
    puts '5. Exit the application'
    choice = read_integer_in_range("Please enter your choice:", 1, 5)
    case choice
    when 1
      albums = read_in_albums
    when 2
      if albums.empty?
        puts "No albums available. Please read in albums first."
      else
        display_albums(albums)
      end
    when 3
      if albums.empty?
        puts "No albums available. Please read in albums first."
      else
        play_album(albums)
      end
    when 4
      add_album(albums)
    when 5
      finished = true
    else
      puts "Invalid selection. Please select again."
    end
  end
end

def read_in_albums
  input = read_string("Enter a file path to an Album:")
  begin
    music_file = File.new(input, "r")
    albums = read_albums(music_file)
    music_file.close
  rescue Errno::ENOENT
    puts "File not found. Please check the file path."
    albums = []
  end
  albums
end

def read_albums(music_file)
  count = music_file.gets.to_i
  albums = []
  count.times { albums << read_album(music_file) }
  albums
end

def read_album(file)
  artist = file.gets
  title = file.gets
  label = file.gets
  genre = file.gets.to_i
  tracks = read_tracks(file)
  Album.new(artist, title, label, genre, tracks)
end

def display_albums(albums)
  finished = false
  until finished
    puts 'Display Albums Menu:'
    puts '1. Display All Albums'
    puts '2. Display Albums by Genre'
    puts '3. Return to Main Menu'
    choice = read_integer_in_range("Please enter your choice:", 1, 3)
    case choice
    when 1
      display_all_albums(albums)
    when 2
      display_genre(albums)
    when 3
      finished = true
    else
      puts "Invalid selection. Please select again."
    end
  end
end

def play_album(albums)
  display_all_albums(albums)
  select_album = read_integer("Enter Album number:")
  if select_album.between?(1, albums.size)
    selected_album = albums[select_album - 1]
    print_album(selected_album)
    puts("\n")
    print_tracks(selected_album.tracks)
    select_track = read_integer("Select a Track to play:")
    if select_track.between?(1, selected_album.tracks.size)
      puts "Playing track #{selected_album.tracks[select_track - 1].name} from album #{selected_album.title}"
      sleep(3)
    else
      puts "Invalid track number."
    end
  else
    puts "Invalid album number."
  end
end

def display_all_albums(albums)
  albums.each_with_index do |album, index|
    puts "#{index + 1}: Title: #{album.title}, Artist: #{album.artist}, Label: #{album.label}, Genre: #{$genre_names[album.genre]}"
  end
end

def print_album(album)
  puts "Title: #{album.title}, Artist: #{album.artist}, Label: #{album.label}, Genre: #{$genre_names[album.genre]}"
end

def display_genre(albums)
  puts "Available genres:"
  $genre_names.each_with_index { |name, index| puts "#{index}. #{name}" if index > 0 }
  user_input = read_integer_in_range("Select a genre by number:", 1, 4)
  albums.each do |album|
    if album.genre == user_input
      puts "Title: #{album.title}, Artist: #{album.artist}, Label: #{album.label}, Genre: #{$genre_names[album.genre]}"
    end
  end
end

def add_album(albums)
  artist = read_string("Enter artist: ")
  title = read_string("Enter title: ")
  label = read_string("Enter label: ")
  puts "1. Pop\n2. Classic\n3. Jazz\n4. Rock"
  genre = read_integer_in_range("Enter number of genre: ", 1, 4)
  count_tracks = read_integer("Enter number of tracks: ")

  tracks = []
  count_tracks.times do
    track_name = read_string("Enter the name of the track:")
    track_location = read_string("Enter the location of the track:")
    tracks << Track.new(track_name, track_location)
  end

  new_album = Album.new(artist, title, label, genre, tracks)
  albums << new_album
  puts "Album '#{title}' by #{artist} added successfully!"
end

def pause
  puts "Press any key to continue..."
  STDIN.getch
  puts "\n"
end

def main
  main_menu
end

main


