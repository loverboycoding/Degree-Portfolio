def print_silly_name(name):
    print(f"{name} is a")  # Print name and 'is a' on the same line
    i = 0
    while i < 60:
        print("silly", end=' ')  # Print 'silly' on the same line with spaces in between
        i += 1  # Increment i
    print("name!")  # Move to a new line and print 'name!'

def main():
    name = input("What is your name?\n")
    if name == "Ted" or name == "Fred":
        print(name + " is an awesome name!")
    else:
        print_silly_name(name)  # Call the print_silly_name function

main()

